"""Actual EQ setters plus generated notification thunk, OS services stubbed."""
from pathlib import Path
import sys,struct,unittest
sys.path[:0]=[str(Path(__file__).resolve().parents[1]/'tools'),str(Path(__file__).parent)]
import test_v13,build_v14 as b
from unicorn import Uc,UC_ARCH_RISCV,UC_MODE_RISCV64,UC_HOOK_CODE
from unicorn.riscv_const import *
class EQTest(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.result,cls.config,cls.report=b.build(test_v13.BASE.read_bytes())
  fs=b.c.image_items(cls.result)['data_udisk.fex']['data']
  _,cls.segs=b.m.decompress_file(fs,next(e for e in b.m.parse(fs) if e['name']=='init.axf'))
  original=b.c.image_items(test_v13.BASE.read_bytes())['data_udisk.fex']['data']
  _,cls.original_segs=b.m.decompress_file(original,next(e for e in b.m.parse(original) if e['name']=='init.axf'))
 def execute(self,index,level,preset,_baseline=False):
  u=Uc(UC_ARCH_RISCV,UC_MODE_RISCV64);u.mem_map(0xe9100000,0x200000)
  for a,data,t in (self.original_segs if _baseline else self.segs):
   if a!=0xffff0000:u.mem_write(a,data)
  cfg=0x10000000;stack=0x20001000;ret=0x30000000
  for addr in [cfg,stack-4096,ret]:u.mem_map(addr,4096)
  u.mem_write(0xe92e8298,struct.pack('<Q',cfg))
  u.mem_write(cfg+0x8c8,struct.pack('<i',preset))
  u.mem_write(cfg+0x8d4,bytes((j*7)%256 for j in range(0x68)))
  before=bytes(u.mem_read(cfg+0x8d4,0x68));u.mem_write(0xe9297890,bytes([0x55])*0x68)
  u.reg_write(UC_RISCV_REG_SP,stack);u.reg_write(UC_RISCV_REG_RA,ret);u.reg_write(UC_RISCV_REG_A0,level)
  for j,r in enumerate([UC_RISCV_REG_S0,UC_RISCV_REG_S1,UC_RISCV_REG_S2]):u.reg_write(r,0x112200+j)
  calls=[]
  def hook(uc,a,size,user):
   if a==0xe918984e: # memcpy used to restore the user EQ before editing a preset
    dst=uc.reg_read(UC_RISCV_REG_A0);src=uc.reg_read(UC_RISCV_REG_A1);n=uc.reg_read(UC_RISCV_REG_A2)
    uc.mem_write(dst,bytes(uc.mem_read(src,n)));uc.reg_write(UC_RISCV_REG_PC,uc.reg_read(UC_RISCV_REG_RA))
   elif a==b.CONTROL:
    calls.append(('audio',uc.reg_read(UC_RISCV_REG_A0),uc.reg_read(UC_RISCV_REG_A1)))
    uc.reg_write(UC_RISCV_REG_A0,0x1234);uc.reg_write(UC_RISCV_REG_PC,uc.reg_read(UC_RISCV_REG_RA))
   elif a==b.NOTIFY:
    calls.append(('notify',uc.reg_read(UC_RISCV_REG_A0)))
    uc.reg_write(UC_RISCV_REG_A0,0x5678);uc.reg_write(UC_RISCV_REG_PC,uc.reg_read(UC_RISCV_REG_RA))
  u.hook_add(UC_HOOK_CODE,hook);u.emu_start(b.SETTERS[index],ret,count=250)
  self.assertEqual(u.reg_read(UC_RISCV_REG_PC),ret);self.assertEqual(u.reg_read(UC_RISCV_REG_SP),stack)
  self.assertEqual(u.reg_read(UC_RISCV_REG_A0),0x1234)
  for j,r in enumerate([UC_RISCV_REG_S0,UC_RISCV_REG_S1,UC_RISCV_REG_S2]):self.assertEqual(u.reg_read(r),0x112200+j)
  self.assertEqual(calls,[('audio',[30,60,125,250,500,1000,2000,4000,8000,16000][index],level)]+([] if _baseline else [('notify',3000)]))
  self.assertEqual(struct.unpack('<i',u.mem_read(cfg+0x8c8,4))[0],0)
  field=cfg+0x8e0+4*([0,1,2,3,4,5,6,7,8,11][index])
  self.assertEqual(struct.unpack('<i',u.mem_read(field,4))[0],level)
  state=(bytes(u.mem_read(cfg,4096)),bytes(u.mem_read(0xe9297890,0x68)))
  if not _baseline:self.assertEqual(state,self.execute(index,level,preset,True))
  return state
 def test_all_bands_levels_and_modes(self):
  for band in range(10):
   for level in range(15):
    for preset in [0,1]:
     with self.subTest(band=band,level=level,preset=preset):self.execute(band,level,preset)
 def test_deterministic(self):self.assertEqual(b.build(test_v13.BASE.read_bytes())[0],self.result)
if __name__=='__main__':unittest.main()
