"""Execute the generated setter and stock gain code; not a hardware test."""
from pathlib import Path
import sys,struct,unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
import build_v13 as b,minfs_codec as m,image_checks as c
from unicorn import Uc,UC_ARCH_RISCV,UC_MODE_RISCV64,UC_HOOK_CODE
from unicorn.riscv_const import *
BASE=Path('/workspace/scratch/fr7002-analysis/NAV_FACTORY/Update/XFHF133.img')
class NativeTest(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.result,cls.config,cls.report=b.build(BASE.read_bytes())
  fs=c.image_items(cls.result)['data_udisk.fex']['data']
  _,cls.segs=m.decompress_file(fs,next(e for e in m.parse(fs) if e['name']=='init.axf'))
 def execute(self,level,maxvol):
  u=Uc(UC_ARCH_RISCV,UC_MODE_RISCV64)
  u.mem_map(0xe9100000,0x200000)
  for va,data,t in self.segs:
   if va!=0xffff0000:u.mem_write(va,data)
  cfg=0x10000000;stack=0x20001000;ret=0x30000000
  for addr in [cfg,stack-4096,ret]:u.mem_map(addr,4096)
  u.mem_write(0xe92e8298,struct.pack('<Q',cfg))
  u.mem_write(cfg+0x30c,struct.pack('<i',maxvol))
  u.mem_write(cfg+0x868,struct.pack('<i',19))
  u.mem_write(0xe92e4f4b,bytes([77]))
  u.mem_write(0xe92e4f45,bytes([89]))
  u.reg_write(UC_RISCV_REG_SP,stack);u.reg_write(UC_RISCV_REG_RA,ret)
  u.reg_write(UC_RISCV_REG_A0,level&((1<<64)-1))
  saved=[UC_RISCV_REG_S0,UC_RISCV_REG_S1,UC_RISCV_REG_S2]
  for j,reg in enumerate(saved):u.reg_write(reg,0x111100+j)
  events=[]
  def hook(uc,addr,size,user):
   if addr==0xe91b8cc0: # maxVolume getter called by the original gain routine
    uc.reg_write(UC_RISCV_REG_A0,maxvol&((1<<64)-1));uc.reg_write(UC_RISCV_REG_PC,uc.reg_read(UC_RISCV_REG_RA))
   elif addr==0xe91c1b38:
    events.append(uc.reg_read(UC_RISCV_REG_A0));uc.reg_write(UC_RISCV_REG_PC,uc.reg_read(UC_RISCV_REG_RA))
  u.hook_add(UC_HOOK_CODE,hook)
  u.emu_start(b.SETTER,ret,count=300)
  self.assertEqual(u.reg_read(UC_RISCV_REG_PC),ret)
  self.assertEqual(u.reg_read(UC_RISCV_REG_SP),stack)
  for j,reg in enumerate(saved):self.assertEqual(u.reg_read(reg),0x111100+j)
  self.assertEqual(events,[3000])
  self.assertEqual(u.mem_read(0xe92e4f45,1),bytes([89]))
  actual=struct.unpack('<i',u.mem_read(cfg+0x868,4))[0];gain=u.mem_read(0xe92e4f4b,1)[0]
  if maxvol<=0:self.assertEqual((actual,gain),(19,77))
  else:
   expected=min(max(level,0),maxvol)
   self.assertEqual(actual,expected);self.assertEqual(gain,expected*100//maxvol)
 def test_all_levels(self):
  for maxvol in [1,20,33,50,100]:
   for level in list(range(maxvol+1))+[-1,-100,255,1000]:
    with self.subTest(maxvol=maxvol,level=level):self.execute(level,maxvol)
 def test_invalid_max(self):
  for mv in [0,-1]:self.execute(15,mv)
 def test_reject_wrong_input(self):
  with self.assertRaises(AssertionError):b.build(BASE.read_bytes()[:-1])
 def test_radio_flags(self):
  for line in [b'defaultSource=BtMusic\r\n',b'bRadioBackgroundRun=0\r\n',b'bRadioSoundAtCarPlay=0\r\n']:self.assertIn(line,self.config)
 def test_deterministic(self):self.assertEqual(b.build(BASE.read_bytes())[0],self.result)
if __name__=='__main__':unittest.main()
