"""EQ-save notification candidate, built from exact NAV_FACTORY through v13."""
from pathlib import Path
import argparse,struct,json
import build_v13 as v13,image_checks as c,minfs_codec as m
EQ_CAVE=0xe9254e50
TAILS=[0xe91b9c0a,0xe91b9c86,0xe91b9d02,0xe91b9d7e,0xe91b9dfa,0xe91b9e76,0xe91b9ef2,0xe91b9f70,0xe91b9ff0,0xe91ba170]
SETTERS=[0xe91b9baa,0xe91b9c22,0xe91b9c9e,0xe91b9d1a,0xe91b9d96,0xe91b9e12,0xe91b9e8e,0xe91b9f0a,0xe91b9f88,0xe91ba108]
CONTROL=0xe918cbec
NOTIFY=0xe91c1b38

def eq_code():
 code=bytearray()
 def emit(x):code.extend(x)
 emit(v13.addi(2,2,-32));emit(v13.store(1,2,24,3))
 emit(v13.jal(1,EQ_CAVE+len(code),CONTROL))
 emit(v13.store(10,2,8,3)) # Preserve the original return value.
 emit(v13.word((1<<12)|(10<<7)|0x37));emit(v13.addi(10,10,-1096))
 emit(v13.jal(1,EQ_CAVE+len(code),NOTIFY))
 emit(v13.mem(3,10,2,8,3));emit(v13.mem(3,1,2,24,3))
 emit(v13.addi(2,2,32));emit(v13.word(0x00008067))
 return bytes(code)

def build(base):
 previous,config,report=v13.build(base)
 items=c.image_items(previous);fs=items['data_udisk.fex']['data']
 _,segs=m.decompress_file(fs,next(e for e in m.parse(fs) if e['name']=='init.axf'))
 code=eq_code();assert v13.segment_read(segs,EQ_CAVE,len(code))==bytes(len(code))
 patches=[]
 for a in TAILS:
  assert v13.segment_read(segs,a,4)==v13.jal(0,a,CONTROL),hex(a)
  patches.append((a,v13.jal(0,a,EQ_CAVE)))
 patches.append((EQ_CAVE,code))
 outfs=m.patch_image(fs,'init.axf',patches);before=c.fs_paths(fs);after=c.fs_paths(outfs)
 changed=[]
 for name,e in before.items():
  if e['Attr']&1:continue
  n=after[name]
  if fs[e['Offset']:e['Offset']+e['Size']]!=outfs[n['Offset']:n['Offset']+n['Size']]:changed.append(name)
 assert changed==['apps/init.axf']
 _,outsegs=m.decompress_file(outfs,next(e for e in m.parse(outfs) if e['name']=='init.axf'))
 for a,data,t in segs:
  expected=bytearray(data)
  for addr,repl in patches:
   if a<=addr<a+len(data):expected[addr-a:addr-a+len(repl)]=repl
  assert v13.segment_read(outsegs,a,len(data))==expected
 result=bytearray(previous);item=items['data_udisk.fex']
 result[item['offset']:item['offset']+item['length']]=outfs
 struct.pack_into('<I',result,items['Vdata_udisk.fex']['offset'],c.sum32(outfs))
 check=c.image_items(result)
 for name,item in items.items():
  if name not in ['data_udisk.fex','Vdata_udisk.fex']:assert check[name]==item
 report.update(output_sha256=c.sha(result),EQ_save_notification_added=True,EQ_storage_fix='candidate_not_hardware_verified',pairing_fix=False,EQ_patched_setters=len(TAILS),EQ_cave_address=hex(EQ_CAVE),EQ_cave_bytes=len(code))
 return bytes(result),config,report

def main():
 ap=argparse.ArgumentParser();ap.add_argument('image',type=Path);ap.add_argument('output',type=Path);args=ap.parse_args()
 result,config,report=build(args.image.read_bytes());assert not args.output.exists()
 (args.output/'Update').mkdir(parents=True)
 (args.output/'Update/XFHF133.img').write_bytes(result);(args.output/'Update/Config.ini').write_bytes(config)
 (args.output/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
