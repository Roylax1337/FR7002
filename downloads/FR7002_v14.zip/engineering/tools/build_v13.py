"""Exact-input FR7002 NAV_FACTORY radio/navigation candidate; no hardware I/O."""
from pathlib import Path
import argparse,struct,hashlib,json
import image_checks as c,minfs_codec as m
if not __debug__:
 raise RuntimeError('Run without -O: input and layout assertions are required')
BASE='468f3248a89d07973205ee0f22bca57e7918fa31a4cb63d1a79e00fb82848190'
CAVE=0xe9254e00
SETTER=0xe91bbc3c
SOURCE=0xe91b1582
SOURCE_OLD=bytes.fromhex('17150900130565ce67800000010001000100010001000100')
def word(x):return struct.pack('<I',x)
def addi(rd,rs,imm):
 assert -2048<=imm<2048
 return word(((imm&4095)<<20)|(rs<<15)|(rd<<7)|0x13)
def mem(op,rd,rs,imm,f3):return word(((imm&4095)<<20)|(rs<<15)|(f3<<12)|(rd<<7)|op)
def store(rs2,rs,imm,f3):
 v=imm&4095
 return word(((v>>5)<<25)|(rs2<<20)|(rs<<15)|(f3<<12)|((v&31)<<7)|0x23)
def branch(rs1,rs2,off,f3):
 assert off%2==0 and -4096<=off<4096
 x=off&8191
 return word(((x>>12)<<31)|(((x>>5)&63)<<25)|(rs2<<20)|(rs1<<15)|(f3<<12)|(((x>>1)&15)<<8)|(((x>>11)&1)<<7)|0x63)
def jal(rd,pc,target):
 off=target-pc;assert off%2==0 and -(1<<20)<=off<(1<<20)
 x=off&0x1fffff
 return word(((x>>20)<<31)|(((x>>1)&1023)<<21)|(((x>>11)&1)<<20)|(((x>>12)&255)<<12)|(rd<<7)|0x6f)
def auipc_addr(rd,pc,target):
 delta=target-pc;hi=(delta+2048)>>12;lo=delta-(hi<<12)
 return word(((hi&0xfffff)<<12)|(rd<<7)|0x17)+addi(rd,rd,lo)
def nav_code():
 # Stack and all callee-saved registers follow the original RISC-V ABI.
 code=bytearray()
 def emit(b):code.extend(b)
 emit(addi(2,2,-16));emit(store(1,2,8,3))
 emit(auipc_addr(15,CAVE+len(code),0xe92e8298))
 emit(mem(3,15,15,0,3)) # a5 = runtime configuration
 emit(mem(3,14,15,0x30c,2)) # a4 = maxVolume
 # Invalid max: leave field and gain untouched, then notify like stock.
 invalid=len(code);emit(bytes(4))
 nonnegative=len(code);emit(bytes(4));emit(addi(10,0,0))
 within=len(code);emit(bytes(4));emit(addi(10,14,0))
 emit(addi(15,15,2047));emit(addi(15,15,105)) # cfg + 0x868
 emit(store(10,15,0,2))
 emit(jal(1,CAVE+len(code),0xe9197fd0)) # Apply real Alt coefficient now.
 tail=len(code)
 emit(mem(3,1,2,8,3));emit(addi(2,2,16));emit(addi(10,0,0xbb8-4096))
 # 3000 cannot fit addi; use LUI+ADDI instead of negative immediate.
 del code[-4:];emit(word((1<<12)|(10<<7)|0x37));emit(addi(10,10,-1096))
 emit(jal(0,CAVE+len(code),0xe91c1b38))
 code[invalid:invalid+4]=branch(0,14,tail-invalid,5) # bge zero,max -> tail
 code[nonnegative:nonnegative+4]=branch(10,0,8,5)
 code[within:within+4]=branch(14,10,8,5)
 return bytes(code)
def segment_read(segs,va,n):
 found=[b[va-a:va-a+n] for a,b,t in segs if a<=va and va+n<=a+len(b)]
 assert len(found)==1,hex(va)
 return found[0]
def replacement_config(config):
 changes={'defaultSource':('Radio','BtMusic'),'bRadioBackgroundRun':('1','0'),'bRadioSoundAtCarPlay':('1','0')}
 for key,(old,new) in changes.items():
  before=(key+'='+old+'\r\n').encode();after=(key+'='+new+'\r\n').encode()
  assert config.count(before)==1,key
  config=config.replace(before,after)
 return config
def build(base):
 assert c.sha(base)==BASE,'Only exact NAV_FACTORY input accepted'
 items=c.image_items(base);fs=items['data_udisk.fex']['data'];paths=c.fs_paths(fs)
 ent=next(e for e in m.parse(fs) if e['name']=='init.axf');_,segs=m.decompress_file(fs,ent)
 assert segment_read(segs,SOURCE,len(SOURCE_OLD))==SOURCE_OLD
 nav=nav_code();assert segment_read(segs,CAVE,len(nav))==bytes(len(nav))
 oldsetter=segment_read(segs,SETTER,4);assert oldsetter.hex()=='97c71200'
 patches=[(SETTER,jal(0,SETTER,CAVE)),(CAVE,nav)]
 updated=m.patch_image(fs,'init.axf',patches)
 # Size-changing config is placed in unused tail, preserving every other file.
 outfs=bytearray(updated);newpaths=c.fs_paths(outfs);cfg=newpaths['apps/Config.ini']
 assert cfg['Attr']==0
 config=replacement_config(bytes(outfs[cfg['Offset']:cfg['Offset']+cfg['Size']]))
 first=min(e['Offset'] for e in newpaths.values() if not e['Attr']&1)
 end=max(e['Offset']+e['Size'] for e in newpaths.values() if not e['Attr']&1)
 offset=(end+15)&~15;assert offset+len(config)<=len(outfs)
 outfs[offset:offset+len(config)]=config
 struct.pack_into('<III',outfs,cfg['record'],offset,len(config),len(config))
 struct.pack_into('<I',outfs,24,offset+len(config)-first)
 finalpaths=c.fs_paths(outfs)
 changed=[]
 for name,e in paths.items():
  if e['Attr']&1:continue
  n=finalpaths[name]
  before=fs[e['Offset']:e['Offset']+e['Size']];after=outfs[n['Offset']:n['Offset']+n['Size']]
  if before!=after:changed.append(name)
 assert sorted(changed)==['apps/Config.ini','apps/init.axf']
 _,newsegs=m.decompress_file(outfs,next(e for e in m.parse(outfs) if e['name']=='init.axf'))
 for va,b in patches:assert segment_read(newsegs,va,len(b))==b
 for va,b,t in segs:
  expected=bytearray(b)
  for addr,repl in patches:
   if va<=addr<va+len(b):expected[addr-va:addr-va+len(repl)]=repl
  assert segment_read(newsegs,va,len(b))==expected
 result=bytearray(base);r=items['data_udisk.fex'];result[r['offset']:r['offset']+r['length']]=outfs
 struct.pack_into('<I',result,items['Vdata_udisk.fex']['offset'],c.sum32(outfs))
 checked=c.image_items(result)
 for n,v in items.items():
  if n not in ['data_udisk.fex','Vdata_udisk.fex']:assert checked[n]==v,n
 return bytes(result),config,{'input_sha256':BASE,'output_sha256':c.sha(result),'bytes':len(result),'changed_files':changed,'nav_apply_synchronous':True,'home_interface_preserved':True,'EQ_storage_fix':False,'pairing_fix':False,'hardware_tested':False,'cave_address':hex(CAVE),'cave_bytes':len(nav)}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('image',type=Path);ap.add_argument('output',type=Path);args=ap.parse_args()
 result,config,report=build(args.image.read_bytes());assert not args.output.exists()
 (args.output/'Update').mkdir(parents=True)
 (args.output/'Update/XFHF133.img').write_bytes(result)
 (args.output/'Update/Config.ini').write_bytes(config)
 (args.output/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report,indent=2))
if __name__=='__main__':main()
