#!/usr/bin/env python3
"""Shared validation of FR7002 IMAGEWTY/MINFS and Factory button resources.

Python 3 standard library. Never flashes hardware or edits the input image.
No --force option: other versions are rejected before output creation.
"""
from pathlib import Path
import argparse,hashlib,json,struct,zlib

BASE_SHA='d3db31a6a6be4fc7fb512dc974b222a0c2dcd59f7138886d169a4c287fff2cfb'
TARGET='apps/Data/SetupMenu.data'
BUTTON=0x1018
ACTION=BUTTON+8+0xf0
sha=lambda b:hashlib.sha256(b).hexdigest()
u32=lambda b,p:struct.unpack_from('<I',b,p)[0]

def require(condition,message):
    if not condition:raise ValueError(message)

def sum32(data):
    require(len(data)%4==0,'Unaligned checksum data')
    return sum(struct.unpack('<%dI'%(len(data)//4),data))&0xffffffff

def image_items(image):
    require(image[:8]==b'IMAGEWTY' and u32(image,8)==0x300,'Unexpected image format')
    require(struct.unpack_from('<Q',image,24)[0]==len(image)==16411648,'Unexpected image size')
    require(tuple(u32(image,p) for p in (56,60,64))==(1024,8,1024),'Unexpected item table')
    items={}
    for i in range(8):
        p=1024+i*1024
        require(u32(image,p)==0x100 and u32(image,p+4)==1024,'Invalid item header')
        name=image[p+36:p+292].split(b'\0')[0].decode('ascii')
        allocation,length,offset=struct.unpack_from('<3Q',image,p+292)
        require(name not in items and offset%1024==0 and offset>=9216 and length<=allocation
                and offset+allocation<=len(image),'Invalid item bounds')
        items[name]={'offset':offset,'length':length,'allocation':allocation,'data':image[offset:offset+length]}
    require(set(items)=={'boot0_nor.fex','sunxi_gpt.fex','sunxi_mbr_nor.fex','dlinfo.fex',
                        'melis_pkg_nor.fex','Vmelis_pkg_nor.fex','data_udisk.fex','Vdata_udisk.fex'},'Unexpected items')
    spans=sorted((e['offset'],e['offset']+e['allocation']) for e in items.values())
    require(all(a[1]<=b[0] for a,b in zip(spans,spans[1:])),'Overlapping image items')
    for name in ('melis_pkg_nor.fex','data_udisk.fex'):
        require(u32(items['V'+name]['data'],0)==sum32(items[name]['data']),name+' checksum failed')
    g=items['sunxi_gpt.fex']['data'];h=bytearray(g[512:1024]);crc=u32(h,16)
    struct.pack_into('<I',h,16,0)
    require(zlib.crc32(h[:u32(h,12)])==crc,'GPT header CRC failed')
    count,size,crc=struct.unpack_from('<3I',h,80)
    require(zlib.crc32(g[1024:1024+count*size])==crc,'GPT table CRC failed')
    for i in range(4):
        part=items['sunxi_mbr_nor.fex']['data'][i*16384:(i+1)*16384]
        require(u32(part,0)==zlib.crc32(part[4:]),'MBR CRC failed')
    d=items['dlinfo.fex']['data']
    require(u32(d,0)==zlib.crc32(d[4:]) and u32(d,16)==2,'Download descriptor CRC failed')
    require([d[32+72*i:48+72*i].split(b'\0')[0] for i in range(2)]==[b'bootA',b'ROOTFS'],
            'Unexpected update partitions')
    return items

def fs_paths(fs):
    require(fs[:5]==b'MINFS','Invalid MINFS')
    paths={};seen=set()
    def walk(offset,length,parent=''):
        end=offset+length
        require(32<=offset<=end<=len(fs),'Directory bounds failed')
        while offset<end:
            require(offset not in seen and offset+20<=end,'Invalid directory record')
            seen.add(offset)
            start,size,unpack,reclen,attr,nlen,elen=struct.unpack_from('<III4H',fs,offset)
            require(reclen>=20+((nlen+3)&~3)+elen and offset+reclen<=end,'Record length failed')
            name=fs[offset+20:offset+20+nlen].decode('utf-8')
            path=parent+name
            require(path not in paths and '/' not in name and name not in ('.','..'),'Invalid path')
            paths[path]={'Offset':start,'Size':size,'UnPack':unpack,'Attr':attr,'record':offset,
                         'metadata':bytes(fs[offset:offset+reclen])}
            if attr&1:walk(start,size,path+'/')
            else:require(0x5000<=start<=start+size<=len(fs),'File bounds failed')
            offset+=reclen
        require(offset==end,'Directory end mismatch')
    walk(*struct.unpack_from('<II',fs,8))
    require(len(seen)==u32(fs,16),'Unreachable or missing MINFS records')
    ranges=sorted((e['Offset'],e['Offset']+e['Size']) for e in paths.values() if not e['Attr']&1)
    require(all(a[1]<=b[0] for a,b in zip(ranges,ranges[1:])),'Overlapping file payloads')
    return paths

def patch_button(payload):
    require(payload[:8]==b'D\0A\0T\0A\0','Invalid DATA resource')
    name=payload[BUTTON+8:BUTTON+208].decode('utf-16le').split('\0')[0]
    require(name=='ViewShowButtonSetupPassword','Unexpected Factory button')
    require(u32(payload,ACTION)==0x2b2,'Unexpected Factory button action')
    out=bytearray(payload);struct.pack_into('<I',out,ACTION,0x2af)
    require([i for i,(a,b) in enumerate(zip(payload,out)) if a!=b]==[ACTION],'Unexpected resource changes')
    return bytes(out)
